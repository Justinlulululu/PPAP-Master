
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function askAssistant(question: string, context?: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are PPAP Master Assistant. User context: ${context || 'None'}. Question: ${question}`,
      config: {
        systemInstruction: "You are a specialized assistant for the Production Part Approval Process (PPAP). Help users with questions about AIAG standards, compliance, timelines, and documentation like PSW, FMEA, and Control Plans. Keep answers concise and professional.",
      },
    });
    return response.text || "I'm sorry, I couldn't process that request.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error communicating with the assistant.";
  }
}
