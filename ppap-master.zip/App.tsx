
import React, { useState, useMemo } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { ProjectCard } from './components/ProjectCard';
import { AssistantView } from './components/AssistantView';
import { MOCK_PROJECTS } from './constants';
import { ProjectStatus, View } from './types';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentView, setCurrentView] = useState<View>('projects');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');

  const filteredProjects = useMemo(() => {
    return MOCK_PROJECTS.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            p.partNumber.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesFilter = activeFilter === 'All' || p.status === activeFilter;
      return matchesSearch && matchesFilter;
    });
  }, [searchQuery, activeFilter]);

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen max-w-[480px] mx-auto bg-background-dark shadow-2xl border-x border-slate-800 flex flex-col">
        <LoginScreen onLogin={() => setIsLoggedIn(true)} />
      </div>
    );
  }

  return (
    <div className="relative flex min-h-screen w-full flex-col overflow-hidden max-w-[480px] mx-auto bg-background-dark shadow-2xl border-x border-slate-800">
      
      {currentView === 'projects' && (
        <>
          <header className="sticky top-0 z-30 bg-background-dark/80 backdrop-blur-md border-b border-slate-800 px-6 pt-12 pb-4">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h1 className="text-2xl font-bold text-white">PPAP Projects</h1>
                <p className="text-sm text-slate-400 font-medium">{MOCK_PROJECTS.length} Active Projects</p>
              </div>
              <button className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-white shadow-lg shadow-primary/30 active:scale-95 transition-transform">
                <span className="material-symbols-outlined !text-[24px]">add</span>
              </button>
            </div>
            <div className="relative w-full group">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-primary transition-colors">
                <span className="material-symbols-outlined !text-[20px]">search</span>
              </span>
              <input
                className="w-full h-11 pl-10 pr-4 bg-surface-dark border-none rounded-xl text-sm font-medium text-white placeholder-slate-500 focus:ring-2 focus:ring-primary shadow-sm transition-all outline-none"
                placeholder="Search projects, part numbers..."
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </header>

          <main className="flex-1 overflow-y-auto no-scrollbar px-4 pb-24 pt-2 space-y-3">
            <div className="flex gap-2 mb-4 overflow-x-auto no-scrollbar pb-1 px-1">
              {['All', 'Pending', 'Approved', 'Urgent'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    activeFilter === filter
                      ? 'bg-primary text-white shadow-sm'
                      : 'bg-surface-dark text-slate-300 border border-slate-700 hover:border-slate-500'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>

            {filteredProjects.length > 0 ? (
              filteredProjects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-slate-500">
                <span className="material-symbols-outlined !text-[48px] mb-2">search_off</span>
                <p>No projects found</p>
              </div>
            )}
          </main>
        </>
      )}

      {currentView === 'assistant' && <AssistantView />}
      
      {['tasks', 'alerts', 'profile'].includes(currentView) && (
        <div className="flex-1 flex flex-col items-center justify-center text-slate-400 p-8 text-center">
          <span className="material-symbols-outlined !text-[64px] mb-4">construction</span>
          <h2 className="text-xl font-bold text-white mb-2 capitalize">{currentView} Screen</h2>
          <p>This module is currently being optimized for version 2.1.</p>
        </div>
      )}

      {/* Navigation */}
      <nav className="absolute bottom-0 w-full bg-surface-dark border-t border-slate-800 px-6 py-2 pb-6 z-20">
        <div className="flex justify-between items-center">
          <NavButton 
            active={currentView === 'projects'} 
            icon="dashboard" 
            label="Projects" 
            onClick={() => setCurrentView('projects')} 
          />
          <NavButton 
            active={currentView === 'tasks'} 
            icon="task" 
            label="Tasks" 
            onClick={() => setCurrentView('tasks')} 
          />
          <NavButton 
            active={currentView === 'assistant'} 
            icon="smart_toy" 
            label="Assistant" 
            onClick={() => setCurrentView('assistant')} 
          />
          <NavButton 
            active={currentView === 'alerts'} 
            icon="notifications" 
            label="Alerts" 
            onClick={() => setCurrentView('alerts')} 
          />
          <NavButton 
            active={currentView === 'profile'} 
            icon="person" 
            label="Profile" 
            onClick={() => setCurrentView('profile')} 
          />
        </div>
      </nav>
    </div>
  );
};

interface NavButtonProps {
  active: boolean;
  icon: string;
  label: string;
  onClick: () => void;
}

const NavButton: React.FC<NavButtonProps> = ({ active, icon, label, onClick }) => (
  <button
    onClick={onClick}
    className={`flex flex-col items-center gap-1 p-2 transition-colors ${
      active ? 'text-primary' : 'text-slate-500 hover:text-slate-300'
    }`}
  >
    <span className="material-symbols-outlined text-[24px]">{icon}</span>
    <span className="text-[10px] font-semibold">{label}</span>
  </button>
);

export default App;
