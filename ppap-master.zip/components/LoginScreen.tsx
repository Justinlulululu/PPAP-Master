
import React, { useState } from 'react';

interface LoginScreenProps {
  onLogin: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [agreed, setAgreed] = useState(false);

  return (
    <div className="flex-1 flex flex-col justify-between h-full bg-background-dark text-white">
      {/* Hero Section */}
      <div className="flex-1 flex flex-col justify-center items-center px-6 pt-20 pb-8 relative">
        <div className="absolute top-0 left-0 w-full h-[300px] bg-gradient-to-b from-primary/10 to-transparent pointer-events-none"></div>
        <div className="relative w-24 h-24 mb-6 rounded-2xl bg-gradient-to-br from-primary to-blue-600 shadow-lg shadow-primary/30 flex items-center justify-center transform transition-transform hover:scale-105 duration-300">
          <span className="material-symbols-outlined text-white !text-[48px]">schedule</span>
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-white text-center mb-2">
          PPAP Master
        </h1>
        <p className="text-slate-400 text-base font-normal leading-relaxed text-center max-w-[280px]">
          Track Timelines. Manage Approvals.<br />Stay compliant effortlessly.
        </p>
      </div>

      {/* Action Area */}
      <div className="flex flex-col gap-4 px-6 pb-8 w-full">
        <button
          onClick={onLogin}
          disabled={!agreed}
          className={`relative flex w-full cursor-pointer items-center justify-center overflow-hidden rounded-xl h-14 bg-[#07C160] hover:bg-[#06ad56] text-white transition-all active:scale-[0.98] shadow-md shadow-green-900/20 group ${!agreed ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <span className="material-symbols-outlined mr-2 !text-[24px]">chat</span>
          <span className="text-base font-bold tracking-wide">WeChat One-Click Login</span>
        </button>

        <button
          onClick={onLogin}
          disabled={!agreed}
          className={`flex w-full cursor-pointer items-center justify-center overflow-hidden rounded-xl h-14 bg-[#283039] text-white border border-transparent hover:bg-[#323b46] transition-all active:scale-[0.98] ${!agreed ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <span className="material-symbols-outlined mr-2 !text-[24px] fill-1">ios</span>
          <span className="text-base font-bold tracking-wide">Sign in with Apple</span>
        </button>

        <div className="mt-4 flex justify-center">
          <button className="text-sm font-medium text-slate-400 hover:text-primary transition-colors flex items-center gap-1 group">
            Login with Mobile Number
            <span className="material-symbols-outlined !text-[16px] group-hover:translate-x-0.5 transition-transform">arrow_forward</span>
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-auto px-6 pb-8 pt-4">
        <div className="flex items-start gap-3 justify-center">
          <div className="flex h-5 items-center">
            <input
              type="checkbox"
              id="agreed"
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
              className="h-4 w-4 rounded border-slate-600 bg-transparent text-primary focus:ring-primary focus:ring-offset-0"
            />
          </div>
          <div className="text-xs leading-5 text-slate-400">
            <p>
              I have read and agree to the{' '}
              <a className="font-semibold text-primary hover:text-primary/80 hover:underline" href="#">User Agreement</a>{' '}
              and{' '}
              <a className="font-semibold text-primary hover:text-primary/80 hover:underline" href="#">Privacy Policy</a>.
            </p>
          </div>
        </div>
        <p className="text-center text-[10px] text-slate-600 mt-6 uppercase tracking-wider font-semibold">
          Version 2.0.1
        </p>
      </div>
    </div>
  );
};
