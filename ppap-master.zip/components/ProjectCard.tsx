
import React from 'react';
import { Project } from '../types';

interface ProjectCardProps {
  project: Project;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  const isTesla = project.customer === 'Tesla';
  const isGM = project.customer === 'GM';
  const isVW = project.customer === 'VW';
  const isBYD = project.customer === 'BYD';
  
  const bgColors: Record<string, string> = {
    'TS': 'bg-indigo-900/30 text-indigo-400',
    'GM': 'bg-blue-900/30 text-blue-400',
    'VW': 'bg-orange-900/30 text-orange-400',
    'BYD': 'bg-teal-900/30 text-teal-400',
    'LA': 'bg-purple-900/30 text-purple-400'
  };

  const progressColors: Record<string, string> = {
    'Urgent': 'bg-primary',
    'Approved': 'bg-success',
    'Pending': 'bg-slate-400',
    'In Progress': 'bg-primary'
  };

  return (
    <div className="group relative bg-surface-dark rounded-2xl p-4 shadow-sm border border-slate-800 active:scale-[0.99] transition-transform cursor-pointer">
      <div className="flex justify-between items-start mb-3">
        <div className="flex gap-3">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm ${bgColors[project.initials] || 'bg-slate-700 text-slate-300'}`}>
            {project.initials}
          </div>
          <div>
            <h3 className="text-base font-bold text-white leading-tight mb-0.5">{project.name}</h3>
            <p className="text-xs text-slate-400 font-medium">PN: {project.partNumber}</p>
          </div>
        </div>
        <span className={`inline-flex items-center px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wide border ${
          project.phase >= 3 ? 'bg-warning/10 text-warning border-warning/20' : 'bg-slate-700 text-slate-300 border-slate-600'
        }`}>
          Phase {project.phase}
        </span>
      </div>

      <div className="space-y-3">
        <div>
          <div className="flex justify-between text-xs mb-1.5">
            <span className="text-slate-400 font-medium">Completeness</span>
            <span className="text-white font-bold">{project.completeness}%</span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-1.5 overflow-hidden">
            <div 
              className={`h-1.5 rounded-full transition-all duration-500 ${progressColors[project.status] || 'bg-primary'}`} 
              style={{ width: `${project.completeness}%` }}
            ></div>
          </div>
        </div>

        {project.deadline && (
          <div className="flex items-center gap-2 p-2 rounded-lg bg-red-900/20 border border-red-900/30">
            <span className="material-symbols-outlined text-danger !text-[18px]">event_busy</span>
            <div className="flex flex-col">
              <span className="text-[10px] text-danger font-bold uppercase">{project.deadline.label}</span>
              <span className="text-xs font-medium text-slate-200">{project.deadline.date}</span>
            </div>
          </div>
        )}

        {project.nextReview && !project.deadline && (
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-slate-400 !text-[16px]">calendar_today</span>
            <span className="text-xs text-slate-400">Next Review: <span className="text-slate-300 font-semibold">{project.nextReview}</span></span>
          </div>
        )}
      </div>
    </div>
  );
};
