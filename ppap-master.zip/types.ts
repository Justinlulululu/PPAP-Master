
export enum ProjectStatus {
  PENDING = 'Pending',
  APPROVED = 'Approved',
  URGENT = 'Urgent',
  IN_PROGRESS = 'In Progress'
}

export interface Project {
  id: string;
  name: string;
  partNumber: string;
  customer: string;
  initials: string;
  phase: number;
  completeness: number;
  status: ProjectStatus;
  deadline?: {
    label: string;
    date: string;
    isUrgent: boolean;
  };
  nextReview?: string;
}

export type View = 'projects' | 'tasks' | 'alerts' | 'profile' | 'assistant';
