
import { Project, ProjectStatus } from './types';

export const MOCK_PROJECTS: Project[] = [
  {
    id: '1',
    name: 'Tesla Model Y Bracket',
    partNumber: '1044321-00-E',
    customer: 'Tesla',
    initials: 'TS',
    phase: 3,
    completeness: 65,
    status: ProjectStatus.URGENT,
    deadline: {
      label: 'Material Cert Deadline',
      date: 'Due Tomorrow, Oct 24',
      isUrgent: true
    }
  },
  {
    id: '2',
    name: 'GM Battery Cover',
    partNumber: '84439221',
    customer: 'GM',
    initials: 'GM',
    phase: 4,
    completeness: 80,
    status: ProjectStatus.APPROVED,
    nextReview: 'Oct 30, 2024'
  },
  {
    id: '3',
    name: 'VW ID.4 Control Arm',
    partNumber: '11A-407-151',
    customer: 'VW',
    initials: 'VW',
    phase: 1,
    completeness: 15,
    status: ProjectStatus.PENDING,
    nextReview: 'Dec 15, 2024'
  },
  {
    id: '4',
    name: 'BYD Seal Connector',
    partNumber: 'BYD-8821-X',
    customer: 'BYD',
    initials: 'BYD',
    phase: 2,
    completeness: 42,
    status: ProjectStatus.PENDING,
    nextReview: 'Nov 05, 2024'
  },
  {
    id: '5',
    name: 'Lucid Air Air Vent',
    partNumber: 'LUC-990-22',
    customer: 'Lucid',
    initials: 'LA',
    phase: 2,
    completeness: 30,
    status: ProjectStatus.PENDING,
    nextReview: 'Nov 12, 2024'
  }
];
